<?php

namespace Drupal\key\Exception;

/**
 * Defines a generic exception for Key.
 */
class KeyException extends \Exception { }
